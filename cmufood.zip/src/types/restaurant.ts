export interface Restaurant {
  id: string;
  name: string;
  neighborhood: string;
  type: string;
  price: string;
  lat: number | null;
  lng: number | null;
  remarks: string;
}

export interface FilterState {
  neighborhoods: Set<string>;
  types: Set<string>;
  prices: Set<string>;
}

export const emptyFilterState = (): FilterState => ({
  neighborhoods: new Set(),
  types: new Set(),
  prices: new Set(),
});
